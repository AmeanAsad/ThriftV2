self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "32439254f7ea3c490f4e",
    "url": "/static/bundles/css/2.5d45f07d.chunk.css"
  },
  {
    "revision": "5061e24e9885211b8c60",
    "url": "/static/bundles/css/main.b98e9f4f.chunk.css"
  },
  {
    "revision": "e770e417502965eab42a9488024cb6f6",
    "url": "/static/bundles/index.html"
  },
  {
    "revision": "32439254f7ea3c490f4e",
    "url": "/static/bundles/js/2.d663407b.chunk.js"
  },
  {
    "revision": "5061e24e9885211b8c60",
    "url": "/static/bundles/js/main.5c0d70ec.chunk.js"
  },
  {
    "revision": "37fa14d1633d34f844d6",
    "url": "/static/bundles/js/runtime~main.afeb355a.js"
  },
  {
    "revision": "473e16a23150fc45cf19a1fdce67fcd8",
    "url": "/static/bundles/media/background.473e16a2.jpg"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/bundles/media/logo.5d5d9eef.svg"
  }
]);